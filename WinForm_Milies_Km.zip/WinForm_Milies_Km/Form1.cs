﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WinForm_Milies_Km
{
    public partial class mainFrm : Form
    {
        public mainFrm()
        {
            InitializeComponent();
        }
        
        
        //нажатие клавиши в поле редактирования
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Правильными символами являются цифры,
            //запятая, <Enter>,<BackSpace>
            //При вводе точка заменится на запятую
            //Чтобы запрещенный символне отображался в поле редактирования
            //присвоим значение true свойству Handler параметра e
            if ((e.KeyChar >= '0') && (e.KeyChar <= '9'))
            {
                return;
            }
            if (e.KeyChar == '.')
            {
                e.KeyChar = ',';
            }
            if (e.KeyChar == ',')
            {
                if (textBox1.Text.IndexOf(',') != -1)
                {
                    //запятая уже есть в поле редактирования
                    e.Handled = true;
                }
                return;
            }
            if (char.IsControl(e.KeyChar))
            {
                //Enter,Backspace, Esc
                // если они нажаты, то переход на кнопку Вычислить
                if (e.KeyChar == (char)Keys.Enter)
                    button1.Focus();
                return;
            }
            //остальные символы запрещены
            e.Handled = true;

        }
        //click  Вычислить
        private void button1_Click(object sender, EventArgs e)
        {
            double mile;
            double km;
            // Если в поле ввода нет данных
            //то при попытке преобразовать пустую
            //строку в число возникает исключение
            try
            {
                mile = Convert.ToDouble(textBox1.Text);
                km = mile * 1.609344;
                label2.Text = km.ToString("n") + " км.";

            }
            catch
            {

                MessageBox.Show("Поле ввода пустое. Повторите ввод", "Предупреждение!");
                textBox1.Focus();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }


    }
}
