﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Aeroflot
{
    class Program
    {
        class Aero
        {
            string naimPort;
            int nomR;
            string typeS;

            public Aero()
            {
                this.naimPort = "Nonaim";
                this.nomR = 0;
                this.typeS = "Notype";
            }
            public Aero(string naim, int reis, string type)
            {
                this.naimPort = naim;
                this.nomR = reis;
                this.typeS = type;
            }
            public string GetNaimPort()
            {
                return naimPort;
            }
            public int GetNomR()
            {
                return nomR;
            }
            public string GetTypeS()
            {
                return typeS;
            }
            public string NaimPort
            {
                get { return naimPort; }
                set { naimPort = value; }

            }
            public int NomR
            {
                get { return nomR; }
                set { nomR = value; }
            }
            public string TypeS
            {
                get { return typeS; }
                set { typeS = value; }
            }

            public void ConsoleOut()
            {
                string str = string.Format("|{0,20} | {1,10} | {2,15}", NaimPort, NomR, TypeS);
                Console.WriteLine(str);
            }


        }
        static void Main()
        {
           
            List<Aero> AeroComp = new List<Aero>(); //список самолетов
            bool flag = true;

            while (flag)
            {
                Console.WriteLine("Пример программы на использование классов (проект АЭРОФЛОТ)");
                Console.WriteLine("1-Ввод данных");
                Console.WriteLine("2-Запись в файл");
                Console.WriteLine("3-Чтение из файла");
                Console.WriteLine("4-Поиск записи по названию");
                Console.WriteLine("99-Конец работы");
                int step = Convert.ToInt32(Console.ReadLine());

                string path = @"D:\AAAA\C#Projects\Aeroflot\Aeroflot\bin\aeroflot.dat";
                switch (step)
                {
                    case 1:
                        {
                            string mk = "y";

                            do
                            {
                                Console.WriteLine("ввод исходных данных и запись их в список");

                                Console.Write("\nВведите пункт назначения: ");
                                string nn = Console.ReadLine();
                                Console.Write("Введите номер рейса:  ");
                                int rr = Convert.ToInt32(Console.ReadLine());
                                Console.Write("Введите тип самолета:  ");
                                string tt = Console.ReadLine();
                                Console.Write("Продолжить? y/n:  ");
                                mk = Console.ReadLine();

                                AeroComp.Add(new Aero() { NaimPort = nn, NomR = rr, TypeS = tt });

                            }
                            while (mk != "n");
                            foreach (Aero a in AeroComp)
                            {
                                Console.WriteLine("{0} {1} {2}", a.NaimPort, a.NomR, a.TypeS);
                            }

                            break;


                        }
                    case 2:
                        {
                            Console.WriteLine("Запись данных в файл");
                            try
                            {

                                using (BinaryWriter writer = new BinaryWriter(File.Open(path, FileMode.OpenOrCreate)))
                                {

                                    foreach (Aero a in AeroComp)
                                    {
                                        writer.Write(a.NaimPort);
                                        writer.Write(a.NomR);
                                        writer.Write(a.TypeS);
                                    }
                                }
                                Console.WriteLine("Запись данных в файл завершена.");
                                Console.ReadKey();
                            }
                            catch (Exception exp)
                            {
                                Console.WriteLine("Ошибка открытия файла. Подробности: \n" + exp.Message);
                            }
                            break;
                        }
                    case 3:
                        {
                            Console.WriteLine("Чтение из файла");
                            List<Aero> spAeros = new List<Aero>();
                            int i = 0;
                            try
                            {
                                using (BinaryReader reader = new BinaryReader(File.Open(path, FileMode.Open)))
                                {
                                    while (reader.PeekChar() > -1)
                                    {
                                        string nn = reader.ReadString();
                                        int rr = reader.ReadInt32();
                                        string tt = reader.ReadString();
                                        spAeros.Add(new Aero { NaimPort = nn, NomR = rr, TypeS = tt });
                                        i++;
                                    }
                                    Console.WriteLine("Файл считан, обработано {0} записей", i);
                                    foreach (Aero a in spAeros)
                                    {
                                        string str = string.Format("|{0,20} | {1,10} | {2,15}", a.NaimPort, a.NomR, a.TypeS);
                                        Console.WriteLine(str);
                                    }
                                }

                            }
                            catch (Exception exp)
                            {
                                Console.WriteLine("Ошибка открытия файла. Подробности: \n" + exp.Message);
                            }

                            break;
                        }
                    case 4:
                        {
                            Console.WriteLine("Поиск записи (в сохраненном файле)");
                            List<Aero> spAeros = new List<Aero>();
                            int i = 0;
                            try
                            {
                                Console.Write("\nВведите название пункта назначения: ");
                                string np = Console.ReadLine();

                                using (BinaryReader reader = new BinaryReader(File.Open(path, FileMode.Open)))
                                {
                                    while (reader.PeekChar() > -1)
                                    {
                                        string nn = reader.ReadString();
                                        int rr = reader.ReadInt32();
                                        string tt = reader.ReadString();
                                        if (nn == np)
                                        {
                                            Console.WriteLine("{0,20}|{1,10}|{2,15}|", nn, rr, tt);
                                            i += 1;
                                        }

                                    }
                                    if (i == 0)
                                    {
                                        Console.WriteLine("Пункт назначения не найден");
                                    }
                                    else
                                        Console.WriteLine("найдено {0,3} записей", i);
                                }

                            }
                            catch (Exception exp)
                            {
                                Console.WriteLine("Ошибка открытия файла. Подробности: \n" + exp.Message);
                            }
                            break;
                        }
                    case 99:
                        {
                            Console.WriteLine("Для завершения работы нажмите на любую клавишу...");
                            flag = false;
                            break;
                        }

                }

            }
            Console.ReadKey();

        }
    }
}
